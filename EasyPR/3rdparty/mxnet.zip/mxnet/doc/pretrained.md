Pretrained Model Gallary
========================
This document contains the the pretrained in MXNet

* [89.9% Top-5 Validation Accuracy for ImageNet 1,000 Classes Challenge](https://github.com/dmlc/mxnet-model-gallery/tree/master/imagenet-1k-inception)
* [37.2% Top-1 Training Accuracy for Full ImageNet 21,841 Classes](https://github.com/dmlc/mxnet-model-gallery/tree/master/imagenet-21k-inception)

