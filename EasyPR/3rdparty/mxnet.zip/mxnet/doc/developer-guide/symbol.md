Symbol Interface
================

Symbol
------

Node
----

DataEntry
---------

Atomic Symbol
-------------

Symbol Composition
------------------

Static Graph
------------

Autodiff
--------
