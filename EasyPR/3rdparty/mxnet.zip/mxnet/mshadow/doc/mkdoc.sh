#!/bin/bash
cd ..
doxygen doc/Doxyfile
cd doc
