/*!
 *  Copyright (c) 2015 by Contributors
 * \file unary_function.cc
 * \brief CPU Implementation of unary function.
 */
// this will be invoked by gcc and compile CPU version
#include "./unary_function-inl.h"
